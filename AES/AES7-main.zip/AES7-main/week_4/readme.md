This folder contains useful files and examples used during week 4 of AES7
