This folder contains useful files and examples used during week 2 of AES7
