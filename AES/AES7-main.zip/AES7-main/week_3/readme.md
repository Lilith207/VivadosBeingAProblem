This folder contains useful files and examples used during week 3 of AES7
