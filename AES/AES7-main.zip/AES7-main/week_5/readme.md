This folder contains useful files and examples used during week 5 of AES7
